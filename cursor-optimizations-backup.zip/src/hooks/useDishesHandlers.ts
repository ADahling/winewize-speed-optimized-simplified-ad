// --- START OF FILE ---

import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWineProcessingState } from './useWineProcessingState';
import { useToast } from './use-toast';

export function useDishesHandlers() {
  const navigate = useNavigate();
  const { setWineProcessingComplete } = useWineProcessingState();
  const { toast } = useToast();

  const handlePairingsReady = useCallback(() => {
    setWineProcessingComplete(true);
    window.dispatchEvent(new Event('wineProcessingComplete'));
    navigate('/pairings');
  }, [navigate, setWineProcessingComplete]);

  const handleProcessingError = useCallback((error: Error) => {
    toast({
      title: 'Processing Error',
      description: error.message,
      status: 'error',
    });
    setWineProcessingComplete(false);
  }, [toast, setWineProcessingComplete]);

  return {
    handlePairingsReady,
    handleProcessingError,
  };
}

// --- END OF FILE ---