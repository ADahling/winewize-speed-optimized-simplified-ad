import { useCallback } from 'react';
import { useSessionOnlyMode } from '@/hooks/useSessionOnlyMode';

// Pairing mode detection logic extracted from useWinePairing
export const usePairingMode = () => {
  const { isSessionOnly } = useSessionOnlyMode();

  const detectPairingMode = useCallback(() => {
    if (isSessionOnly) return 'SESSION';
    
    const currentRestaurantId = localStorage.getItem('currentRestaurantId');
    if (currentRestaurantId && currentRestaurantId !== 'session-only') {
      const sessionResults = sessionStorage.getItem('currentSessionResults');
      if (!sessionResults) return 'IMPORT';
    }
    
    const sessionResults = sessionStorage.getItem('currentSessionResults');
    if (sessionResults) {
      try {
        const results = JSON.parse(sessionResults);
        if (results.restaurantId && results.restaurantId !== 'session-only') return 'UPLOAD';
        if (results.sessionOnly || results.restaurantId === 'session-only') return 'SESSION';
      } catch (error) {
        // Silent fallback - no logging
      }
    }
    
    return 'SESSION';
  }, [isSessionOnly]);

  // CORRECTED: Check currentSessionResults.wines FIRST (where analyze-menu-fast stores them)
  const getSessionWines = useCallback(() => {
    try {
      console.log('🍷 WINE DATA RETRIEVAL - Starting with priority order...');
      
      // PRIORITY 1: Check currentSessionResults FIRST (where analyze-menu-fast stores them)
      const sessionResults = sessionStorage.getItem('currentSessionResults');
      if (sessionResults) {
        try {
          const results = JSON.parse(sessionResults);
          if (results && Array.isArray(results.wines) && results.wines.length > 0) {
            console.log(`✅ Found ${results.wines.length} wines in currentSessionResults.wines`);
            return results.wines;
          }
        } catch (e) {
          console.error('❌ Error parsing currentSessionResults:', e);
        }
      }
      
      // PRIORITY 2: Check sessionWines (secondary location)
      const sessionWines = sessionStorage.getItem('sessionWines');
      if (sessionWines) {
        try {
          const wines = JSON.parse(sessionWines);
          if (Array.isArray(wines) && wines.length > 0) {
            console.log(`✅ Found ${wines.length} wines in sessionWines storage`);
            return wines;
          }
        } catch (e) {
          console.error('❌ Error parsing sessionWines:', e);
        }
      }
      
      // PRIORITY 3: Full session storage scan (existing fallback)
      console.log('🔍 Scanning ALL session storage for wine data...');
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key && (key.includes('wine') || key.includes('Wine') || key.includes('session'))) {
          try {
            const value = sessionStorage.getItem(key);
            if (value) {
              const parsed = JSON.parse(value);
              console.log(`🔍 Found storage key: ${key}`, parsed);
              
              // Check if this is wine data
              if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].name) {
                console.log(`✅ FOUND WINES in ${key}: ${parsed.length} wines`);
                return parsed;
              }
              
              // Check if it's an object with wine arrays
              if (parsed && typeof parsed === 'object') {
                const wineKeys = ['wines', 'wineItems', 'menuWines', 'restaurantWines'];
                for (const wineKey of wineKeys) {
                  if (parsed[wineKey] && Array.isArray(parsed[wineKey]) && parsed[wineKey].length > 0) {
                    console.log(`✅ FOUND WINES in ${key}.${wineKey}: ${parsed[wineKey].length} wines`);
                    return parsed[wineKey];
                  }
                }
              }
            }
          } catch (e) {
            // Skip invalid JSON
          }
        }
      }
      
      console.error('❌ No wines found in any session storage location after complete scan');
      return [];
    } catch (error) {
      console.error('❌ Error retrieving session wines:', error);
      return [];
    }
  }, []);

  return {
    detectPairingMode,
    getSessionWines
  };
};