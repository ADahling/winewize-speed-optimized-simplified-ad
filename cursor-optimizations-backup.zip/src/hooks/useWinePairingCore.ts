
import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { usePairingMode } from '@/hooks/usePairingMode';
import { useWineRetrieval } from '@/hooks/useWineRetrieval';
import { useWineValidation } from '@/hooks/useWineValidation';
import { useUsageManagement } from '@/hooks/useUsageManagement';
import { usePairingApiCalls } from '@/hooks/usePairingApiCalls';
import { useWineProcessingState } from '@/hooks/useWineProcessingState';
import { transformPairingResponse, storePairingResults } from '@/utils/pairingResponseUtils';
import { useAuth } from '@/contexts/AuthContext';

// Streamlined core wine pairing logic
export const useWinePairingCore = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const { user } = useAuth();
  const { detectPairingMode } = usePairingMode();
  const { retrieveWines } = useWineRetrieval();
  const { validateAndProcessWines } = useWineValidation();
  const { usageStats, showUpgradePrompt, setShowUpgradePrompt, checkUsageLimit, trackUsage } = useUsageManagement();
  const { getPairingsForDishes, getConsolidatedPairings } = usePairingApiCalls();
  const { wineProcessingComplete } = useWineProcessingState();

  const generatePairings = useCallback(async (selectedDishesInput: any[], suppressErrors = false) => {
    // Simple validation without verbose logging
    let selectedDishes;
    if (selectedDishesInput.length > 0 && typeof selectedDishesInput[0] === 'string') {
      if (!suppressErrors) toast.error('Invalid dish data format. Please try selecting dishes again.');
      return;
    } else {
      selectedDishes = selectedDishesInput;
    }

    if (!selectedDishes?.length) {
      if (!suppressErrors) toast.error('Please select at least one dish to pair wines with');
      return;
    }

    if (!user) {
      if (!suppressErrors) toast.error('Please log in to generate wine pairings');
      return;
    }

    // EMERGENCY FIX: Only block if wine processing is explicitly incomplete AND no dishes available
    const hasMenuData = selectedDishes?.length > 0;
    if (!wineProcessingComplete && !hasMenuData) {
      if (!suppressErrors) toast.error('Menu processing is still in progress. Please wait for it to complete.');
      return;
    }

    // Fast mode detection and usage check
    const pairingMode = detectPairingMode();
    const canProceed = await checkUsageLimit();
    if (!canProceed) return;

    try {
      setIsGenerating(true);
      setError(null);

      let pairingData;

      if (pairingMode === 'SESSION') {
        // Retrieve wines using specialized hook
        const currentRestaurantId = localStorage.getItem('currentRestaurantId');
        const sessionWines = await retrieveWines({ 
          mode: 'SESSION',
          restaurantId: currentRestaurantId || undefined
        });
        
        if (sessionWines.length === 0) {
          throw new Error('No wines found for pairing. Please ensure wine images were uploaded.');
        }

        // Validate and process wines
        const validWines = validateAndProcessWines(sessionWines);

        if (validWines.length === 0) {
          throw new Error('No valid wines found for pairing after processing. Please check wine data quality.');
        }

        // Call session pairing API
        pairingData = await getPairingsForDishes(selectedDishes, undefined, validWines);

      } else if (pairingMode === 'IMPORT' || pairingMode === 'UPLOAD') {
        const currentRestaurantId = localStorage.getItem('currentRestaurantId');
        if (!currentRestaurantId) {
          throw new Error('No restaurant selected');
        }

        const restaurantWines = await retrieveWines({ 
          mode: pairingMode,
          restaurantId: currentRestaurantId
        });

        // Call regular pairing API
        pairingData = await getPairingsForDishes(selectedDishes, currentRestaurantId, restaurantWines);
      }

      // Fast response transformation
      const transformedPairings = transformPairingResponse(pairingData, pairingMode);

      // Store results
      storePairingResults(transformedPairings, selectedDishes);

      if (!suppressErrors) {
        toast.success(`Generated ${transformedPairings.length} wine pairings successfully!`);
      }

      // Track usage
      await trackUsage();

      // CRITICAL FIX: Navigate to pairings page after successful generation
      navigate('/pairings', { 
        state: { 
          pairings: transformedPairings,
          fromDishes: true,
          restaurantId: localStorage.getItem('currentRestaurantId') || 'session-only'
        }
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to generate wine pairings';
      setError(errorMessage);
      if (!suppressErrors) {
        toast.error(errorMessage);
      }
    } finally {
      setIsGenerating(false);
    }
  }, [user, detectPairingMode, retrieveWines, validateAndProcessWines, checkUsageLimit, trackUsage, getPairingsForDishes, wineProcessingComplete, navigate]);

  return {
    isGenerating,
    error,
    generatePairings,
    clearError: () => setError(null),
    usageStats,
    showUpgradePrompt,
    setShowUpgradePrompt
  };
};
