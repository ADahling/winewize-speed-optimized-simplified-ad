import { useCallback } from 'react';

// Simplified wine retrieval - only check currentSessionResults
export const useSimplifiedWineRetrieval = () => {
  
  const getWines = useCallback(() => {
    console.log('🔄 [WineRetrieval] ENTRY: getWines');
    
    try {
      // ONLY check currentSessionResults - no complex fallback logic
      const sessionResults = JSON.parse(sessionStorage.getItem('currentSessionResults') || 'null');
      
      if (sessionResults?.wines?.length > 0) {
        console.log('✅ [WineRetrieval] Found wines in currentSessionResults:', sessionResults.wines.length);
        console.log('🔄 [WineRetrieval] EXIT: getWines success');
        return sessionResults.wines;
      }

      console.log('❌ [WineRetrieval] No wines found in currentSessionResults');
      console.log('🔄 [WineRetrieval] EXIT: getWines empty');
      return [];
    } catch (error) {
      console.error('❌ [WineRetrieval] Error retrieving wines:', error);
      return [];
    }
  }, []);

  return {
    getWines
  };
};