// src/pages/admin/simple-test.tsx
export default function SimpleTest() {
  return <div className="p-8"><h1 className="text-2xl">Simple Test Page</h1></div>;
}
